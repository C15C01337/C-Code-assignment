
from Crypto.Hash import MD5

passwd = input("Enter your password: ")
hash_object = MD5.new()
hash_object.update(f"{passwd}".encode('utf-8'))
ori_hash = hash_object
hash_passwd = hash_object.hexdigest()
print(hash_passwd)
