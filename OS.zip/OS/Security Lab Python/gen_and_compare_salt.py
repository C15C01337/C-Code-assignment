from Crypto.Hash import SHA256, MD5
from Crypto.Protocol.KDF import bcrypt, bcrypt_check
from base64 import b64encode

print("1. Generate a hash")
print("2. Check login")
print("3. Exit Program")
1
while True:
    user_choice = input("Choose a option: ")

    if user_choice == "1":
        password = input("Enter your Password: ").encode('utf-8')
        b64pwd = b64encode(SHA256.new(password).digest())
        bcrypt_hash = bcrypt(b64pwd, 10)
        print(f"The salted hash is: {bcrypt_hash}")
    elif user_choice == "2":
        password_to_test = input('Enter your password: ').encode('utf-8')
        try:
            b64pwd_new = b64encode(SHA256.new(password_to_test).digest())
            value = bcrypt_check(b64pwd_new, bcrypt_hash)
            print("congratulation! You logged In! :)")

        except ValueError:
            print("Incorrect password")
    elif user_choice == "3":
        print("Quitting The Program....")
        break
    else:
        print("Please Choose a correct option")
